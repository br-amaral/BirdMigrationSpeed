

#? *********************************************************************************
#? ----------------------------------    map.R    ----------------------------------
#? *********************************************************************************
#
#! Code to creat a base map to plot species results
#
#! Input ----------------------------------------------
#           - data/data_arr.rds
#           - data/source/traits/data_sensi.rds
#           - data/species_Grid.RData
#           - data/fit_df_tab5.rds
#           - data/master_cell_grid.rds
#           - data/for_green-up_dl.rds

# detach packages and clear workspace
if(!require(freshr)){install.packages('freshr')}
freshr::freshr()

#! Load packages ---------------------------------------
library(conflicted)
library(tidyverse)
library(dplyr)
library(ggplot2)
library(plotly)
library(viridis)
library(maps)
library(mapproj)
library(robustHD)
library(geosphere)

conflicts_prefer(dplyr::select)
conflicts_prefer(dplyr::filter)
# conflicts_prefer(scales::alpha)

#! Make functions --------------------------------------
colanmes <- colnames
lenght <- length
`%!in%` <- Negate(`%in%`)

#! Import data -----------------------------------------
## file paths
ARRI_DATA_PATH  <- "data/data_arr.rds"
SENSI_DATA_PATH <- "data/source/traits/data_sensi.rds"
SPS_GRID_PATH   <- "data/species_Grid.RData"
FIT_DATA_PATH   <- "data/fit_df_tab5.rds"
CELL_GRID_PATH  <- "data/master_cell_grid.rds"
GRUP_DATA_PATH  <- "data/for_green-up_dl.rds"

## read files
load(SPS_GRID_PATH)
arr_master     <- read_rds(ARRI_DATA_PATH) %>% as_tibble() 
sensi          <- read_rds(SENSI_DATA_PATH) %>% as_tibble() 
sensi2         <- read_rds(FIT_DATA_PATH) %>% as_tibble() 
cell_grid_tab4 <- read_rds(CELL_GRID_PATH) %>% as_tibble() 
for_gr         <- read_rds(GRUP_DATA_PATH) %>% as_tibble() 

##  Bird arrival date map - TAB 2 ----------------------------
tc <- sort(unique(arr_master$cell))
cellnumbs <- data.frame(cell = tc, 
                        cell2 = seq(1,length(tc)))

arr_master <- dplyr::left_join(arr_master, cellnumbs, by = "cell") %>% 
  dplyr::select(-cell) %>% 
  rename(cell = cell2)

arr_master3 <- arr_master2 <- arr_master
arr_master2 <- arr_master2 %>% 
  rename(year2 = year)

# load maps and plot formatting
worldmap <- ggplot2::map_data("world")
pp <- ggplot(data = worldmap, aes(x = long, y = lat, 
                                  group = group)) +
  geom_polygon(fill = alpha('black', 0.1), color = NA) +
  coord_map("ortho", orientation = c(35, -80, 0),
            xlim = c(-110, -50), ylim = c(21, 66)) +
  #theme_bw() +
  theme(panel.grid.major = element_line(color = alpha('black', 0.2),
                                        linewidth = 0.5),
        panel.ontop = TRUE,
        panel.background = element_rect(fill = NA),
        legend.title=element_text(size=13),
        legend.spacing.y = grid::unit(0.5, "cm"),
        legend.text=element_text(size=rel(1.2)),
        legend.key.height=grid::unit(0.9,"cm"),
        legend.title.align=0.5,
        axis.title.x=element_blank(),
        axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        axis.title.y=element_blank(),
        axis.text.y=element_blank(),
        axis.ticks.y=element_blank()) +
  xlab('Longitude') +
  ylab('Latitude') +
  geom_path(aes(x = long, y = lat, group = group),
            alpha = 0.4, color = 'black')

rm(worldmap)

TAB <- sensi
TAB <- left_join(TAB, cellnumbs, by="cell") %>% 
  dplyr::select(-cell) %>% 
  rename(cell = cell2)

# Line plot
# all species
sensim_df <- sensi2
qq <- ggplot(sensim_df, aes(lat, sensim, group = species)) +
  geom_line(linewidth = 1, col = "gray") +
  theme_classic() +
  xlab("Latitude (Degrees)") +
  ylab("Sensitivity (Days / Day)") +
  theme(axis.title.y = element_text(size = rel(0.9), angle = 90, margin = margin(r = 10)),
        axis.title.x = element_text(size = rel(0.9), angle = 00),
        axis.text=element_text(size=8, colour = "black")
        #axis.text.y = element_text(angle=90)
  ) 
# add species of interest on top 
doline <- function(species){
  sensim_df_f <- sensim_df[which(sensim_df$species == species),]
  qq + geom_line(data = sensim_df_f, 
                  #alpha = 0.8,
                  linewidth = 1.1,
                  color = 'black')
}

##  Interannual variation - TAB 4 ----------------------------
f1a_green <- 'indianred'
f1a_bird <- '#2686A0'

## Range map
ran_sp <- arr_master3 

#create hex grid
for_gr2 <- left_join(for_gr, cellnumbs, by = "cell") %>% 
  select(-cell) %>% 
  rename(cell = cell2)

#merge hex spatial data with HM data
ran_sp <- left_join(ran_sp, cell_grid_tab4, by = 'cell', relationship = "many-to-many") %>%  
  transmute(species,
            cell,
            cell_lat,cell_lng,
            lat,long)

ran_sp3 <- distinct(ran_sp)
ran_sp3$species <- NA
ran_sp3 <- distinct(ran_sp3)

rr <- pp +
  geom_polygon(data = cell_grid_tab4, aes(x = long, y = lat),
                fill="white",
                inherit.aes = FALSE, alpha = 1) +
  geom_path(data = cell_grid_tab4,
            aes(x = long,y = lat, group = cell),
            inherit.aes = FALSE,
            color = 'black', alpha = 0.2) +
  annotate('text', x = ran_sp3$cell_lng, y = ran_sp3$cell_lat,
            label = ran_sp3$cell, col = 'black', alpha = 0.9,
            size = 3) #+

rrb <- pp +
  geom_polygon(data = cell_grid_tab4, aes(x = long, y = lat),
                fill="white",
                inherit.aes = FALSE, alpha = 1) +
  geom_path(data = cell_grid_tab4,
            aes(x = long,y = lat, group = cell),
            inherit.aes = FALSE,
            color = 'black', alpha = 0.2) 

cat("\n\n DONE!!! \n\n\n")
