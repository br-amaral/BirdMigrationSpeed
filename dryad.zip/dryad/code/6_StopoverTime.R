#? *********************************************************************************
#? -----------------------------   6_StopoverTime.R   ------------------------------
#? *********************************************************************************
# Code to calculate stopover time based on our speed 
#   estimates and bird flight speeds from the literature
#
#! Input ----------------------------------------------
#           - data/final.rds : 
#           - data/source/Speed_data/Speed_table_small.csv : 
#           - data/source/traits/gcb14540-sup-0001-supinfo_mass.csv : 
#
#! Output ----------------------------------------------
#           - data/stopover_percent.csv :

# detach packages and clear workspace
if(!require(freshr)){install.packages('freshr')}
freshr::freshr()

#! Load packages ---------------------------------------
library(conflicted)
library(tidyverse)
library(glue)
library(ggplot2)
library(dplyr)

conflicts_prefer(dplyr::select)
conflicts_prefer(dplyr::filter)
# conflicts_prefer(scales::alpha)

#! Make functions --------------------------------------
colanmes <- colnames
lenght <- length
`%!in%` <- Negate(`%in%`)

#! Source code -----------------------------------------

#! Import data -----------------------------------------
## file paths
FINAL_TIB_PATH  <- "data/final.rds"
FLIGHT_SPE_PATH <- "data/source/Speed_data/Speed_table_small.csv"
MASS_SPE_PATH   <- "data/source/traits/gcb14540-sup-0001-supinfo_mass.csv"

## read files
flight_spe <- read_csv(FLIGHT_SPE_PATH)

mass_tax <- read_csv(MASS_SPE_PATH) %>% 
  dplyr::select(species, Distance_m)

final2 <- readRDS(FINAL_TIB_PATH) %>% 
  mutate(species = as.factor(species), 
          cell = as.factor(cell),
          mig_cell = as.factor(mig_cell),
          sps_cell = as.factor(glue("{species}_{cell}"))) %>% 
  group_by(species) %>% 
  summarise(mig_speed = mean(vArrMag, na.rm = T)) %>% 
  ungroup()

flight_spe2 <- left_join(flight_spe, final2, by = "species") %>% 
  left_join(., mass_tax, by = "species") %>% 
  mutate(flight_speed = flight_speed * 24,
          distance_km  = Distance_m,  
          days_flight = distance_km/flight_speed,
          days_mig = distance_km/mig_speed,
          time_stop = days_mig - days_flight,
          percent_stop = time_stop/days_mig)

mean(flight_spe2$percent_stop)

flight_spe_exp <- flight_spe2 %>% 
  select(species, flight_speed, mig_speed, distance_km, percent_stop) %>% 
  mutate(percent_stop = round(percent_stop, 2),
          mig_speed = round(mig_speed,0),
          distance_km = round(distance_km,0),
          species = str_replace(species, "_", " "))

colnames(flight_spe_exp) <- c("Species name", "Flight Speed (km/day)", "Migratory Speed (km/day)", "Migration distance (km)", "Proportion of time at stopover site")
#write_csv(flight_spe_exp, file = "data/stopover_percent.csv")

cat("\n\n DONE!!! \n\n\n")